package models

class Employee(name:String,age:Int){
  def  getAge = {
    age
  }

  def getName: String ={
    name
  }
}