package models

import com.sun.xml.internal.bind.v2.TODO


trait ITT{
  var emp:List[Employee]
  def deptEmpSize():Int
  def elder():List[Any]
  def younger():List[Any]
  def collectiveAge():Int
  def averageAge():Double
  def vacencies():Int
  def accomadateAndPromotion():Unit
}



