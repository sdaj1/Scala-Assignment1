package models

import scala.util.control.Breaks
import scala.util.control.Breaks.break

class ITTEmployee extends ITT{
  var emp:List[Employee]= ???
  def deptEmpSize():Int= ???

  def elder(): List[Any] = ???

  def younger(): List[Any] = ???

  def collectiveAge(): Int = ???

  def averageAge(): Double = ???

  def vacencies(): Int = ???

  def accomadateAndPromotion(): Unit = ???
}
object ITTEmployee {

  def main(args: Array[String]): Unit = {


    //deptEmpSize()
    //elder()
    //younger()
    //collectiveAge()
    //averageAge()
    //vacencies()
    //accomadateAndPromotion()
    //println(averageAgeIntimeTec())
    // addEmp("Sam",31,1)
    //val elder1 = bod.averageAge()
    //println(s"${elder1} is the elder Person in Board of Director Department and his age is ${elder1}")
  }

  def addEmp(name: String, age: Int, dept: Int): Unit = dept match {
    case 1
    => {
      var bodD = new BoardOfDirector()
      val emp1 = new Employee(name, age)
      bodD.emp = bodD.emp :+ emp1
      println("Employee added in BoardOfDirector Department Successfully")
    }
    case 2
    => {
      var engD = new EngineeringDepartment()
      val emp1 = new Employee(name, age)
      engD.emp = engD.emp :+ emp1
      println("Employee added in Engineering Department Successfully")
    }
    case 3
    => {
      var opD = new Operations()
      val emp1 = new Employee(name, age)
      opD.emp = opD.emp :+ emp1
      println("Employee added in Operations Department Successfully")
    }
    case 4 => {
      var serD = new Services()
      val emp1 = new Employee(name, age)
      serD.emp = serD.emp :+ emp1
      println("Employee added in Services Department Successfully")
    }
    case _ => println("Please Enter Correct Department")
  }


  def averageAgeIntimeTec(): Double = {
    var sum = 0.0

    val bod = BoardOfDirector().averageAge()
    val ed = EngineeringDepartment().averageAge()
    val od = Operations().averageAge()
    val sd = Services().averageAge()
    sum = bod + ed + od + sd
    val avg = sum / 4
    return avg
  }

  def collectiveAgeIntimeTec(): Int = {

    val bod = BoardOfDirector().collectiveAge()
    val ed = EngineeringDepartment().collectiveAge()
    val od = Operations().collectiveAge()
    val sd = Services().collectiveAge()

    val sum = bod + ed + od + sd
    return sum
  }
}